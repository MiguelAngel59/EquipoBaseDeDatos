equipoBaseDeDatos


Miguel Angel Valente Trinidad
Omar Moreno Ordaz    320073861

Para ejecutar el programa debes abrir la terminal y navegar al directorio cd EquipoBaseDeDatos_Practica01/SQL/DOC.
Despues debera de compilar las clases del paquete practica 01 con javac practica01/*.java y ejecutar la interfaz con java practica01.VentanaPrincipal.


